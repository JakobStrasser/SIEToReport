﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Excel;

namespace SIEResultat
{
    public partial class Form1 : Form
    {
        Microsoft.Office.Interop.Excel.Application myApp = new Microsoft.Office.Interop.Excel.Application();
        private List<string> lista;

        private Dictionary<string, string> konton = new Dictionary<string, string>();
        private Dictionary<string, string> dimensioner = new Dictionary<string, string>();
        private List<Objekt> objekten = new List<Objekt>();
        private List<Transaktion> transaktioner = new List<Transaktion>();

        public Form1()
        {
            InitializeComponent();
            button2.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string fileContents = "";

                OpenFileDialog openFileDialog1 = new OpenFileDialog();
                openFileDialog1.Filter = "SIE 4|*.SI";
                openFileDialog1.Title = "Select a SIE File";

                // Show the Dialog.  
                // If the user clicked OK in the dialog and  
                // a .CUR file was selected, open it.  
                if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    // Assign the cursor in the Stream to the Form's Cursor property.  
                    // REGEXP ("([^\"]\\S*|\".+?\")\\s*")   

                    StreamReader sr = new StreamReader(openFileDialog1.FileName);
                    fileContents = sr.ReadToEnd();


                }
                if (fileContents.Length > 1)
                {
                    lista = new List<string>(Regex.Split(fileContents, Environment.NewLine));

                }
                else
                {
                    throw new Exception("Fel vid filinläsning");
                }
                // MessageBox.Show("Rader: " + list.Count);
                button2.Enabled = true;
                this.Update();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fel: " + ex.Message + " \n" + ex.StackTrace);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            toolStripProgressBar1.Maximum = lista.Count;
            string verdatum = "";
            string vertext = "";
            try
            {
                foreach (string currentRow in lista)
                {
                    int hashMark = currentRow.IndexOf("#");
                    if (hashMark >= 0)
                    {
                        int nextSpace = currentRow.Substring(hashMark).IndexOf(" ") + hashMark;
                        string tokenString = currentRow.Substring(hashMark, nextSpace - hashMark);
                        textBox1.Text += Environment.NewLine + tokenString;
                        
                        switch (tokenString)
                        {
                            case "#FLAGGA": break;

                            case "#FORMAT": break;

                            case "#SIETYP": break;

                            case "#PROGRAM": break;

                            case "#GEN": break;
                            case "#FNAMN": break;
                            case "#FNR": break;
                            case "#ORGNR": break;
                            case "#ADRESS": break;
                            case "#KPTYP": break;
                            case "#KONTO":
                                {
                                    char[] charSeparators = new char[] { ' ' };
                                    string[] konto = Regex.Split(currentRow, "([^\"]\\S*|\".+?\")\\s*");
                                    konton.Add(konto[3], konto[5]);
                                    break;
                                }
                            case "#DIM":
                                {
                                    char[] charSeparators = new char[] { ' ' };
                                    string[] dim = Regex.Split(currentRow, "([^\"]\\S*|\".+?\")\\s*");
                                    dimensioner.Add(dim[3], dim[5]);
                                    break;
                                }
                            case "#OBJEKT":
                                {
                                    char[] charSeparators = new char[] { ' ' };
                                    string[] dim = Regex.Split(currentRow, "([^\"]\\S*|\".+?\")\\s*");
                                    objekten.Add(new Objekt(dim[3], dim[5], dim[7]));
                                    break;
                                }
                            case "#TRANS":
                                {
                                    string[] dim;
                                    Dictionary<string, string> objekt = new Dictionary<string, string>();
                                    string brackets = Regex.Match(currentRow, "({.*})").ToString();
                                    brackets = brackets.Substring(1, brackets.Length - 2);

                                    if (brackets.Length > 0)
                                    {
                                        dim = Regex.Split(brackets, "([^\"]\\S*|\".+?\")\\s*");
                                        for (int i = 1; i < dim.Length - 3; i = i + 4)
                                        {
                                            objekt.Add(dim[i].Replace('"',' ').Trim(), dim[i + 2].Replace('"', ' ').Trim());
                                        }
                                    }
                                    string utanObjekt = currentRow.Substring(1, currentRow.IndexOf('{') - 1) + currentRow.Substring(currentRow.IndexOf('}') + 1);
                                    string[] delar = Regex.Split(utanObjekt, "([^\"]\\S*|\".+?\")\\s*");

                                    String transaktionsdatum="";
                                    if (transaktionsdatum.Equals(""))
                                        transaktionsdatum = verdatum;
                                    String kontonr = delar[5].Replace('"', ' ').Trim();
                                    string b  = delar[7].Replace('.', ',').Replace('"',' ').Trim();
                                    double belopp = double.Parse(b);
                                    string transtext="";
                                    if (transtext.Equals(""))
                                        transtext = vertext;
                                    double kvantitet=0.0;
                                    string sign = "";
                                    transaktioner.Add(new Transaktion(objekt, transaktionsdatum, kontonr, belopp, transtext, kvantitet, sign));
                                    break;
                                }
                            case "#VER":
                                {
                                    char[] charSeparators = new char[] { ' ' };
                                    string[] dim = Regex.Split(currentRow, "([^\"]\\S*|\".+?\")\\s*");
                                    verdatum = dim[7].Replace('"', ' ').Trim();
                                    vertext = dim[9].Replace('"', ' ').Trim();
                                    break;
                                }
                            default: break;
}
                    }


                    this.Update();
                    toolStripProgressBar1.Increment(1);
toolStripStatusLabel1.Text = "Bearbetar rad " + toolStripProgressBar1.Value + " av " + toolStripProgressBar1.Maximum;
}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + Environment.NewLine + ex.StackTrace);
            }

            Workbook wb = myApp.Workbooks.Add();

            Worksheet sheet = wb.Sheets.Add();
            sheet.Activate();
            sheet.Cells[1, 1] = "Konto";
            sheet.Cells[1, 2] = "Resultatenhet";
            sheet.Cells[1, 3] = "Projekt";
            sheet.Cells[1, 4] = "Belopp";
            sheet.Cells[1, 5] = "Transaktionsdatum";
            sheet.Cells[1, 6] = "Transaktionstext";
            int r = 2;
            foreach(Transaktion t in transaktioner)
            {
                sheet.Cells[r, 1] = t.Kontonr;
                if(t.Objekt.ContainsKey("1"))
                sheet.Cells[r, 2] = "'" + t.Objekt["1"];
                if (t.Objekt.ContainsKey("6"))
                    sheet.Cells[r, 3] = "'" + t.Objekt["6"];
                sheet.Cells[r, 4] = t.Belopp;
                sheet.Cells[r, 5] = t.Transaktionsdatum;
                sheet.Cells[r, 6] = t.Transtext;
                r++;
            }
            sheet.Activate();
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Excel | *.xlsx";
            sfd.ShowDialog();
            wb.SaveAs(sfd.FileName);
            myApp.Quit();
        }
    }
}

