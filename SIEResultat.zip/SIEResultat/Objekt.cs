﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIEResultat
{
    class Objekt
    {
        private string typ;
        private string id;
        private string namn;

        public Objekt()
        {
            typ = "";
            id = "";
            namn = "";
        }

        public Objekt(string typ, string id, string namn)
        {
            this.typ = typ;
            this.id = id;
            this.namn = namn;
        }

        public string Typ
        {
            get
            {
                return this.typ;
            }
            set
            {
                this.typ = value;
            }
        }
        public string Id
        {
            get
            {
                return this.id;
            }
            set
            {
                this.id = value;
            }
        }
        public string Namn
        {
            get
            {
                return this.namn;
            }
            set
            {
                this.namn = value;
            }
        }
    }
}
