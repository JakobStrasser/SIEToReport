﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIEResultat
{
    class Transaktion
    {
        private Dictionary<string, string> objekt;
        private String transaktionsdatum;
        private String kontonr;
        private double belopp;
        private string transtext;
        private double kvantitet;
        private string sign;


        public Dictionary<string, string> Objekt { get => objekt; set => objekt = value; }
        public string Transaktionsdatum { get => transaktionsdatum; set => transaktionsdatum = value; }
        public string Kontonr { get => kontonr; set => kontonr = value; }
        public double Belopp { get => belopp; set => belopp = value; }
        public string Transtext { get => transtext; set => transtext = value; }
        public double Kvantitet { get => kvantitet; set => kvantitet = value; }
        public string Sign { get => sign; set => sign = value; }

        public Transaktion(Dictionary<string, string> objekt, string transaktionsdatum, string kontonr, double belopp, string transtext, double kvantitet, string sign)
        {
            this.objekt = objekt;
            this.transaktionsdatum = transaktionsdatum;
            this.kontonr = kontonr;
            this.belopp = belopp;
            this.transtext = transtext;
            this.kvantitet = kvantitet;
            this.sign = sign;
        }
    }
}
